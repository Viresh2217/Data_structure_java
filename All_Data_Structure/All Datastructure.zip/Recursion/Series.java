package Recursion;

public class Series {
	
	static void Series1(int n) {
		int i=1;
		Series1(n*i++);
		n*2
			
		
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
