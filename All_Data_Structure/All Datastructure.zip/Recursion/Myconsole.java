package Recursion;

import java.util.*;


public class Myconsole {
 static Scanner sc=new Scanner(System.in);

   public static String getString(String name){
	System.out.println(name);
	return(sc.nextLine());
	
	
}
   public static int getNumber(String number){
	   System.out.println(number);
	  return (sc.nextInt());
	  
	
	
}
   public static String getChar()

   {
	   return sc.nextLine();
   }

	

}
